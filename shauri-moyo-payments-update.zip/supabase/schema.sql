-- Shauri Moyo SDA Church — Donations schema
-- Run this in the Supabase SQL Editor (Project > SQL Editor > New query)

create extension if not exists "pgcrypto";

create table if not exists donations (
  id uuid primary key default gen_random_uuid(),
  fund text not null check (fund in ('tithe_offering', 'building_fund', 'missions_evangelism')),
  amount numeric(12,2) not null check (amount > 0),
  currency text not null default 'KES',
  donor_name text,
  donor_phone text,
  donor_email text,
  payment_method text not null check (payment_method in ('mpesa', 'card')),
  merchant_reference text not null unique,
  pesapal_order_tracking_id text,
  status text not null default 'PENDING' check (status in ('PENDING', 'COMPLETED', 'FAILED', 'REVERSED')),
  confirmation_code text,
  raw_ipn_payload jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_donations_status on donations (status);
create index if not exists idx_donations_tracking_id on donations (pesapal_order_tracking_id);
create index if not exists idx_donations_created_at on donations (created_at desc);

-- Auto-update updated_at on every change
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_donations_updated_at on donations;
create trigger trg_donations_updated_at
  before update on donations
  for each row execute function set_updated_at();

-- Lock the table down: all reads/writes go through server-side API routes
-- using the Supabase SERVICE ROLE key, never the public anon key.
alter table donations enable row level security;
-- No policies are created for the anon/public role on purpose — this means
-- the table is unreachable from the browser entirely. Only your Next.js
-- API routes (using SUPABASE_SERVICE_ROLE_KEY) can read or write it.
